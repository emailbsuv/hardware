Various VHDL programs
