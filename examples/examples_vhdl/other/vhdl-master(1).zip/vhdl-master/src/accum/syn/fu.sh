#!/usr/bin/env sh
xst -intstyle ise -ifn ./fu.scr
