#!/usr/bin/env sh
./accum -gui -tclbatch ./fu.icmd
