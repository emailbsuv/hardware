#include <stdint.h>

void get_tick(uint8_t* x)
{
  *x = 0;
}
