#!/usr/bin/env sh
fuse -intstyle ise -incremental -o counter -prj fu.prj tb
