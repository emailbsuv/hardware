#define FPGA_Registermap_Offset 0
#define Reg_MagicId                                  (FPGA_Registermap_Offset + 0x00)
#define Reg_Control                                  (FPGA_Registermap_Offset + 0x02)
#define R_FPGA_Registermap_Control Reg_Control
#define THROTTLE 0
