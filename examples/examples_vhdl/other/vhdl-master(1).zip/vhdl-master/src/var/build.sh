#!/usr/bin/env sh
ghdl -a main.vhdl
ghdl -e main
