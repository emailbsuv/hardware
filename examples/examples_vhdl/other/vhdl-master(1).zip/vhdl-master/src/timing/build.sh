#!/usr/bin/env sh

$HOME/install/bin/ghdl -i main.vhdl
$HOME/install/bin/ghdl -m main
