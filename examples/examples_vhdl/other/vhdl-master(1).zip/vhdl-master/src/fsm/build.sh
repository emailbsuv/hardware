#!/usr/bin/env sh
ghdl -i main.vhdl
ghdl -m main
