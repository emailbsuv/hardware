#!/usr/bin/env sh
ghdl -a sbone.vhdl main.vhdl
ghdl -e main
