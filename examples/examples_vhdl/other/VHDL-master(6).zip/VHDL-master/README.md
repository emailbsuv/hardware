VHDL
====

Assorted VHDL code from an introductory logic circuits course
