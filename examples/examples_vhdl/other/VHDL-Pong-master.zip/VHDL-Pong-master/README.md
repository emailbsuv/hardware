Developed on a Xilinx Spartan 3 Development board at the Hasso Plattner Institute.

Pong features:
 * VGA output
 * Sound (use any pin on the board, connect it to one wire, ground the other one)
 * Lifebars
 * Fancy Game Over graphic
 * Keyboard input (A/Z, K/M are the control keys, could vary depending on your keyboard though.)

Enjoy. 
