.. post:: Jan 29, 2016
   :tags: VUnit
   :author: lasplund
   :excerpt: 1

Chat with VUnit Users and Developers
====================================
Today I created a VUnit chat room using Gitter. Click the chat icon on
the left of the page to join the discussion.

Lars
