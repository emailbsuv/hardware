.. _python_interface:

Python Interface
================
The Python interface of VUnit is exposed through the :class:`VUnit
<vunit.ui.VUnit>` class that can be imported directly from the
:mod:`vunit <vunit.ui>` module.

Public API
----------
.. automodule:: vunit.ui
.. automodule:: vunit.vunit_cli
