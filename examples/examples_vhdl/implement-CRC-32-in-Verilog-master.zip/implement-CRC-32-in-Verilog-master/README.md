implement-CRC-32-in-Verilog
===========================
Project in Course named
DESIGN AND IMPLEMENTATION OF COMMUNICATION PROTOCOLS in FCU

Include
===========================
CRC-16-serial.v 

CRC-16-serial-test.v
 	
CRC-16-paraller.v
 
CRC-16-paraller-test.v
 
CRC-32-paraller.v
 
CRC-32-paraller-test.v

