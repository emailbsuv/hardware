# UoA_EE209_C&VHDL
2015 ELECTENG 209 Course Project: Embedded C code for the ATMEGA 328P & VHDL code for the EPM7064AELC44 CPLD.

##Project Description
Project Description can be found [here](Project.pdf)

The project name was "A Wireless Energy Monitor"
"The goal of this project is to design and develop a wireless energy monitor to measure and display the
amount of power consumed by a household appliance in a smart house."

Note that the hardware aspects of the project are ignored here. The software aspects had 2 sides: C embedded code for the ATMEGA, and VHDL code fot the CPLD. 

The C code was used to :
- record voltage and current readings
- do power and energy calculations
- store energy data on non-volatile memory
- encode and send data over RF to the base station


The VHDL code (for the CPLD on the base station) was used to:
- receive the UART RF transmission 
- decode the transmission 
- display accordingly on a 4x7 segment display

