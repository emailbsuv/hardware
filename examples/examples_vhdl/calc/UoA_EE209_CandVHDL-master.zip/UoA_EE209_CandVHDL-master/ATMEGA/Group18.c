/*
 * Group18.c
 *
 * Created: 11/08/2015 10:21:39 AM
 *  Author: F.Farhour
 */ 

#define F_CPU 16000000UL				// Clock Speed
#define BAUD 9600						//baud rate
#define MYUBRR ((F_CPU/(16UL*BAUD))-1)	//UBRR value based on baud rate
#define _N_SAMPLES 400					//define number of samples for power calculations
#define _DISPLAY_DELAY 2000				//delay between changing values on display of cpld	

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "prototypes18.h"

/* declare global variables here*/
// Value to store analog result
volatile uint16_t analogV[_N_SAMPLES] = {0};
volatile uint16_t analogI[_N_SAMPLES] = {0};

//timer counter values
volatile uint32_t timer1_count = 0;

//Calibration coefficients
double VCAL = 8.546;//8.658;//8.621574;//8.6;//8.621574;
double ICALpk = 385.7;//374;//390;//394.5;//181.82;//367.52;//362.1;
double ICAL = 0.3857;//0.27273;//0.390;//297.03;
double PHASECAL = 1;

//to count number of adc reads
volatile uint16_t adcCounter = 0;

//ENERGY
volatile unsigned int ENERGY_WS = 0;
volatile float ENERGY_WM = 0;
volatile double energySum = 0;

//volatile unsigned int test_eeprom = 0;

//counter for eeprom reads
volatile uint8_t eeprom_count = 0;

//ADC ISR
ISR(ADC_vect){
	//read low then high
	//current is on ADC0 and voltage is on ADC1
	//timer0_count is reset everytime voltage is read
	//adcCounter: counter used to count number of adc reads
	(ADMUX&(1<<MUX0))?(analogV[adcCounter] = ADCW):(analogI[adcCounter] = ADCW, ++adcCounter); 
	
	//change channel (to voltage or current adc input)
	ADMUX ^=(1<<MUX0);	//toggle between channels ADC0 & ADC1
	
	if(adcCounter==_N_SAMPLES-1){
		adcCounter=0;
	}else{
		// Set ADSC in ADCSRA (0x7A) to start another ADC conversion
		ADCSRA |= (1<<ADSC); // ADC Start Conversion
	}
}

//Timer 1 ISR
ISR(TIMER1_OVF_vect){
	//keep track of number of overflows
	++timer1_count;
	//reset timer start point to 3035
	TCNT1 = 3035;
}

//Button Interrupt (using PCINT0 interrupt handler) - clear EEPROM Energy
ISR(PCINT0_vect){
	PORTB^=(1<<PB5);
	//write first byte (least significant byte)
	EEPROM_write(0,(0 & 0xff));
	//test_eeprom |= EEPROM_read(0) & 0xff;
	//write second byte (most significant byte)
	EEPROM_write(8,((0 >>(8)) & 0xff));
	//reset variable
	ENERGY_WS = 0;
	ENERGY_WM = 0;
}

//PD2 used as software interrupt (INT0 set when PD2 written a logic 1) - WRITE to EEPROM
ISR(INT0_vect){
	PORTB^=(1<<PB5);
	++eeprom_count;
	//write first byte (least significant byte)
	EEPROM_write(0,(ENERGY_WS & 0xff));
	//write second byte (most significant byte)
	EEPROM_write(8,((ENERGY_WS >>(8)) & 0xff));
	PORTB^=(1<<PB5);
}

int main(void)
{
	//EEPROM_write(0,7);
/* INITIALIZE ENERGY VALUES - READ FROM EEPROM */
	ENERGY_WS |= EEPROM_read(0) & 0xff;			//read least significant byte
	ENERGY_WS |= (EEPROM_read(8)<<(8));			//read most significant byte
	ENERGY_WM = ENERGY_WS/60.0;
/* ------------------------------------------- */
	
/***initialize ports **/
	DDRB|=(1<<PB5);		//set PORTB: bit 5 as output (light)
	DDRB|=(0<<PB7);		//set PORTB: bit 7 as input (button)
	DDRC = 0x0C;		//make port C, bits 0 and 1, input as it will be connected to analogue device. BINARY = 0b00001100.Also sets PC2,3 as outputs (GainResistor control)
	DDRD|=(1<<PD2);		//set PORTD: but 2 as output (used as an INT0 software interrupt)
/* ------------------ */
	
/* INITIALISE ADC & UART */
	
	//Initialize adc by calling the function;
	adc_init();
	
	//Initialise USART
	USART_Init(MYUBRR);
	
	/* Global Interrupt Enable */
	sei();
	
	//start adc conversion
	ADCSRA |= (1<<ADSC); // ADC Start Conversion
	
/* --------------------- */

/* INITIALISE TIMER */
	timer1_init();

/* ---------------- */	

/* INITIALISE PIN INTERRUPTS */
	pininterrupt_init();
	
/* ------------------------- */

/* DECLARE / INITIALISE VARIABLES */
	//GROUP ID
	int g_groupID = 18; //TODO store this in eeprom
	
	//hard coded values to send to USART
	uint8_t TXBUF[5];
	uint8_t txindex = 0;
	int timercounter=0;
	uint8_t displayLoop = 0;
	uint8_t data;
	uint8_t disp = 0;
	
	//counter for the calculations
	uint16_t calc_count = 0;
	
	/*POWER/ENERGY CALCULATION VARIABLES*/
	float vin = 0 ;
	float iin = 0;
	float instPower = 0;
	double Vrms = 0;
	double Ipk = 0;
	double Ipk2 = 0;
	double realPower = 0;
	double filteredV = 0;
	double filteredI = 0;
	double lastVin, lastIin, lastFilteredV, lastFilteredI;
	//Stores the phase calibrated instantaneous voltage.
	double calibratedV;
	double sqV, sumV, sumP;

/* ------------------------------ */
	
/* MAIN WHILE LOOP */
	while (1){
		
	//TODO CHECK WHEN ADC CONVERSION IS DONE FOR ALL SAMPLES??????
	//if statement to check if adc readings are done
	if(adcCounter==0){
	/* POWER CALCULATIONS */
		/* calculations */
		if(calc_count<_N_SAMPLES){
			//used for offset removal
			lastVin = vin;
			lastIin = iin;
			
			//Calculate Vin and Iin here
			vin = convertAnalog(analogV[calc_count]);
			iin = convertAnalog(analogI[calc_count]);
			
			//used for offset removal
			lastFilteredV = filteredV;
			lastFilteredI = filteredI;
			
			//Digital High-pass filter to remove 2.5V DC offset
			filteredV = 0.996 * (lastFilteredV+vin-lastVin);
			filteredI = 0.996 * (lastFilteredI+iin-lastIin);
			
			//Phase calibration goes here.
			calibratedV = lastFilteredV + PHASECAL * (filteredV - lastFilteredV);
			
			//find max value of filteredI
			if(calc_count==0){
				Ipk = filteredI;
			}else if(Ipk<filteredI){
				Ipk = filteredI;
			}
			
			//Root-mean-square method voltage
			//1) square voltage values
			sqV= calibratedV * calibratedV;
			//2) sum
			sumV += sqV;
			
			//Instantaneous Power
			instPower = calibratedV *  filteredI;
			//Sum
			sumP += instPower;
			
			++calc_count;
		}else{
			calc_count = 0;
			
			//Calculation of the root of the mean of the voltage and current squared (rms)
			//Calibration coefficients applied.
			Vrms = VCAL*sqrt(sumV / _N_SAMPLES);
			
/**/			
			/* Software interrupt for EEPROM Write */
			//NOTE: instead of this might be able to see if voltage from regulator drops below 5 (falling edge)
			if((Vrms<10) && (eeprom_count==0)){
				//write logic 1 to PD2
				PORTD^=(1<<PD2);
			}else if(Vrms>10){
				eeprom_count = 0;
			}
/**/			
			Ipk2 = Ipk *ICALpk;
			
			//Calculating power values
			realPower =(VCAL * ICAL * sumP)/ _N_SAMPLES;
			//calculate energy
			energySum  += realPower;
			
			/* Energy Calculation + timer reset*/
			if(timer1_count>=5){
				//ENERGY_WS is unsigned int, but KWS is float. WIll use KWS to display,but WS to store in EEPROM
				ENERGY_WS += (energySum) * timer1_count ;
				ENERGY_WM = ENERGY_WS/60.0;
				timer1_count = 0;
			}

			//------------------------------------------------
			//Reset accumulators
			sumV = 0;
			sumP = 0;
			Ipk = 0;
			
			// Set ADSC in ADCSRA (0x7A) to start another ADC conversion
			ADCSRA |= (1<<ADSC); // ADC Start Conversion
			
		}
		
	}
		/* DISPLAY DATA */
		if(timercounter<_DISPLAY_DELAY){
			timercounter++;
		}else{
			//if Vrms falls below 2 it displays -FAS-
			if(Vrms>=1.5){
				//Vrms units
				if(disp==0){
					makeUnitPackets(TXBUF,disp);
				//Vrms
				}else if(disp==1){
					makePackets(Vrms,TXBUF,g_groupID);
					
				//Ipeak units
				}else if(disp==2){
					makeUnitPackets(TXBUF,disp);
					
				//Ipeak
				}else if(disp==3){
					makePackets(Ipk2,TXBUF,g_groupID);
					
				//real average power unit
				}else if(disp==4){
					makeUnitPackets(TXBUF,disp);
				
				//real average power
				}else if(disp==5){
					makePackets(realPower,TXBUF,g_groupID);
				
				//energy unit
				}else if(disp==6){
					makeUnitPackets(TXBUF,disp);
					
				//total energy
				}else if(disp==7){
					makePackets(ENERGY_WM,TXBUF,g_groupID);
					//makePackets(test_eeprom,TXBUF,g_groupID);
				}
				disp = (disp+1)%8;
				
				/* DISPLAY -FAS-*/
			}
			
			
			
			
			else{
				if(displayLoop==0){
					TXBUF[4] = 0b11010011; //-
					TXBUF[3] = 0b10111010; //F
					TXBUF[2] = 0b11001001; //A
					TXBUF[1] = 0b01101000; //S
					++displayLoop;
				}else if(displayLoop==1){
					TXBUF[4] = 0b10111011; //F
					TXBUF[3] = 0b11001010; //A
					TXBUF[2] = 0b01101001; //S
					TXBUF[1] = 0b11010000; //-
					++displayLoop;
				}else if(displayLoop==2){
					TXBUF[4] = 0b11001011; //A
					TXBUF[3] = 0b01101010; //S
					TXBUF[2] = 0b11010001; //-
					TXBUF[1] = 0b10111000; //F
					++displayLoop;
				}else if(displayLoop==3){
					TXBUF[4] = 0b01101011; //S
					TXBUF[3] = 0b11010010; //-
					TXBUF[2] = 0b10111001; //F
					TXBUF[1] = 0b11001000; //A
					displayLoop = 0;
				};
			}
			
			//GROUP ID
			TXBUF[0] = g_groupID;
			
			//reset variables
			timercounter = 0;
		}
		
	/* -------------- */
	
	
	/* TRANSMIT DATA */
		data = TXBUF[txindex];
		UART_Transmit(data);
		// increment index
		if(txindex<4){
			++txindex;
		}else{
			txindex = 0;
		}
	/* ------------- */
		
	}
	return 0;
};