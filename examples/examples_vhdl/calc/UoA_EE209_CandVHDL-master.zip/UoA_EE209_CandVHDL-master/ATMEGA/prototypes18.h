#include <avr\io.h>
#include "functions18.c"

void USART_Init( unsigned int myubrr);
void UART_Transmit(uint8_t data );
void adc_init(void);
void read_adc(int readFlag);
float convertAnalog(uint16_t analogVal);
void makePackets(float vin, uint8_t TXBUF[], int groupID);
void makeUnitPackets(uint8_t TXBUF[], uint8_t unit);
void timer1_init();
void pininterrupt_init();
void EEPROM_write(unsigned int uiAddress, unsigned char ucData);
unsigned char EEPROM_read(unsigned int uiAddress);