#include <util\delay.h>
#include <math.h>

//USART
void USART_Init(unsigned int myubrr)
{
	// Set baud rate using register UBRR0H and UBRR0L
	UBRR0H = (myubrr>>8);
	UBRR0L = myubrr;
	/*Set status registers*/
	UCSR0A = (0<<RXC0) | (0<<TXC0) | (0<<UDRE0) | (0<<FE0) | (0<<DOR0) | (0<<UPE0) | (0<<U2X0) | (0<<MPCM0);
	// Enable transmitter
	UCSR0B = (0<<RXCIE0)| (0<<TXCIE0) | (0<<UDRIE0) | (0<<RXEN0) |  (1<<TXEN0)  | (0<<UCSZ02) | (0<<RXB80) | (0<<TXB80);
	// Select 8-bit frame, single stop bit and no parity using UCSR0C
	UCSR0C = (0<<UMSEL01) | (0<<UMSEL00)| (0<<UPM00) | (0<<UPM01) | (1<<UCSZ01) | (1<<UCSZ00) | (0<<UCPOL0);
}
void UART_Transmit(uint8_t data )
{
	
	/* Wait for empty transmit buffer */
	while(!(UCSR0A & (1<<UDRE0)));
	/* Put data into buffer, sends the data */
	UDR0 = data;
	
	
	/* you can put delay statement here*/
	//_delay_ms(1000);
	
}

//ADC
void adc_init(void){
	/** Setup and enable ADC **/
	//TODO
	//Reference Selection Bits
	ADMUX = (0<<REFS1)| // Reference Selection Bits -> select AREF
	(0<<REFS0)| // AVcc - external cap at AREF -> select AREF
	(0<<ADLAR)| // ADC Left Adjust Result -> have right justified to use all 10-bits
	//Mux select -> 000: PC0 (I out); 001: PC1 (V out).
	(0<<MUX2)| // Analog Channel Selection Bits -> start at PC0
	(0<<MUX1)| // ADC2 (PC2 PIN25) -> start at PC0
	(0<<MUX0); // ->start at PC0
	
	ADCSRA = (1<<ADEN)| // ADC ENable
	(0<<ADSC)| // ADC Start Conversion
	(0<<ADATE)| // ADC Auto Trigger Enable -> NO AUTO TRIGGER
	(0<<ADIF)| // ADC Interrupt Flag
	(1<<ADIE) | // ADC Interrupt Enable -> Using Interrupts
	(1<<ADPS2)| // ADC Prescaler Select Bits: Max is 16 -> 1MHz. We have 32 -> 500kHz
	(1<<ADPS1)|
	(1<<ADPS0);
	
	//ADCSRB |= (0<<ADTS0) | (0<<ADTS1) | (0<<ADTS2);	//set trigger source to free running mode
}

float convertAnalog(uint16_t analogVal){
	float x = 0.0;
	x = ((analogVal/1024.0)*5);
	return x;
}

void makePackets( float vin, uint8_t TXBUF[],int groupID){
	//count number of digits before dec.point
	int digits = 0;
	
	
	float x = 0;
	x = vin;
	
	while((int)x){
		x/=10.0;
		digits++;
	}
	int dec = 0 ;
	if(digits==0){
		dec = 3;
		digits = 1;
	}else{
		dec = (4 - digits);
	}
	//round to 4 digits in total (e.g. if 1 whole number before dp, will be rounded to 3 decimal points.
	
	int number = vin * (pow(10,dec)); //round to dec dp
	
	//Initialise Segment numbers and x (x, SEG1, SEG0)
	/*
	uint8_t seg = 0b00000000;
	for(int i=0; i<4;i++){
		TXBUF[i] = seg;
		seg |= (1<<i+5);
	}
	*/
	TXBUF[1] = 0b00000000;
	TXBUF[2] = 0b00000001;
	TXBUF[3] = 0b00000010;
	TXBUF[4] = 0b00000011;
	
	//NOTE: TXBUF index will increase  in same order as does the segment number on 7-seg display
	//set DP on corresponding segment
	TXBUF[dec+1] |= 0b00000100;
	
	//convert from float to int (get rid of dp)
	//int number = nearest * (pow(10,dec));
	int temp;
	//loop to go through all digits, find least-sig digit, add to corresponding index, move to next digit
	//number/=10;
	for(int i=1; i<5; i++){
		temp = (groupID-(number % 10)); //Encryption of the data (18 - actual number)
		TXBUF[i] |= temp<<3;	//shift left by 3 for new data frame structure
		number/=10;
	}
	//unit = the letter showing what the value represents. unit = 0bxxxxx011 (since segment 3)
	
}

//Create packets for unit display
void makeUnitPackets(uint8_t TXBUF[], uint8_t unit){
	//unit: 0-Volt. 2-CURR. 4-AVG.P. 6-TOT.E.
	if(unit==0){
		TXBUF[4] = 0b10110011;	//V
		TXBUF[3] = 0b11000010;	//o
		TXBUF[2] = 0b10001001;	//l
		TXBUF[1] = 0b11100100;	//t.
		
	}else if(unit==2){
		TXBUF[4] = 0b10101011;	//C
		TXBUF[3] = 0b11111010;	//u
		TXBUF[2] = 0b11101001;	//r
		TXBUF[1] = 0b11101100;	//r.
	}else if(unit==4){
		TXBUF[4] = 0b11001011;	//A
		TXBUF[3] = 0b10110010;	//V
		TXBUF[2] = 0b11110101;	//G.
		TXBUF[1] = 0b10100100;	//P.
	}else if(unit==6){
		TXBUF[4] = 0b11100011;	//t
		TXBUF[3] = 0b11000010;	//o
		TXBUF[2] = 0b11100101;	//t.
		TXBUF[1] = 0b10011100;	//E.
	}
}

void timer1_init(){
	//normal mode operation
	TCCR1A = (0<<COM1A1)|
	(0<<COM1A0)|
	(0<<COM1B1)|
	(0<<COM1B0)|
	(0<<WGM10)|
	(0<<WGM11);
	
	TCCR1B = (0<<ICNC1)|
	(0<<ICES1)|
	(0<<WGM13)|
	(0<<WGM12)|
	(1<<CS12)|
	(0<<CS11)|
	(0<<CS10);
	
	TCNT1 = 3035;	//start timer at 3035 counts to 65535 and resets
	TIMSK1 = (1<<TOIE1);	//set timer/counter interrupt enable
	
}

//initialize interrupts for pins
void pininterrupt_init(){
	/* initialise interrupts for button pin */
	PCICR |= (1<<PCIE0);		//Pin Change Interrupt Enable 0
	PCMSK0 |= (1<<PCINT7);	//If PCINT7 is set and the PCIE0 bit in PCICR is set, pin change interrupt is enabled on the corresponding I/O pin.
	
	/* initialise interrupts for PD2 (software interrupt) */
	EICRA |= (0<<ISC01)|(1<<ISC00);	//Any logical change on INT0 generates an interrupt request.
	EIMSK |= (1<<INT0);	//External Interrupt Request 0 Enable
	
}

//EEPROM WRITE FUNCTION FROM ATMEL AVR DATASHEET
//NOTE: only writes 1 byte at a time. So need to 
void EEPROM_write(unsigned int uiAddress, unsigned char ucData)
{
	//DISABLE GLOBAL INTERRUPTS
	cli();
	
	/* Wait for completion of previous write */
	while(EECR & (1<<EEPE));
	/* Set up address and Data Registers */
	EEAR = uiAddress;
	EEDR = ucData;
	/* Write logical one to EEMPE */
	EECR |= (1<<EEMPE);
	/* Start eeprom write by setting EEPE */
	EECR |= (1<<EEPE);
	
	//wait for write operation to finish, and re-enable global interrupts
	while(EECR & (1<<EEPE));
	sei();
}

unsigned char EEPROM_read(unsigned int uiAddress)
{
	cli();
	/* Wait for completion of previous write */
	while(EECR & (1<<EEPE));
	
	/* Set up address register */
	EEAR = uiAddress;
	/* Start eeprom read by writing EERE */
	EECR |= (1<<EERE);
	/* Return data from Data Register */
	return EEDR;
}
