# vhdl-calculator
Simple calculator built in VHDL, using an Altera board and Quartus software
