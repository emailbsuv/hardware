# Keypad_Scanner
Scan a 4*5 keypad and return the keypress to a processor through SPI; This code is written in VHDL.

The keypad scanner is implemented with 2 seperated finite state machines. The first machine serves as the controller for the input buffers. The second machine controls the SPI buffer. See the comments inside the code for more informations
