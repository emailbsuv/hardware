fpga-spi-comms
==============

A simple SPI slave and test environment in VHDL. The test environment displays the last two bytes received from the master on seven segment displays and sends back a counter indicating the cumulative number of received bytes.  
