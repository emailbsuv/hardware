spi_fpga
========
Simple exercise, a SPI Master written in VHDL. In order to use it, the clock must be lower than the one of the FPGA, so even a (simple) clock divider has been written.

**Not yet tested on FPGA, but waveforms are correct**
