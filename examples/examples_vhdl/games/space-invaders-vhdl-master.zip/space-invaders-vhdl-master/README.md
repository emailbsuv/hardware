space-invaders-vhdl
===================

This is a simple implementation of Space Invaders in VHDL.

![space invaders vhdl](https://cloud.githubusercontent.com/assets/294960/12948430/54edd600-cfe9-11e5-8b4f-f5a18ceff89a.gif)

A gameplay video can be found here: http://cameraweb.ccuec.unicamp.br/watch_video.php?v=SC66ZN8645GG

# Gameplay

To change between screens, press `5` or `space`.

The keys `4` and `6` move the player ship to the left and right, respectively. To shoot, press `5` or `space`.

