Ethernet-communication-VHDL
===========================

FPGA implementation of Real-time Ethernet communication using RMII Interface

Paper is availabe at:
http://ieeexplore.ieee.org/xpls/abs_all.jsp?arnumber=6013943&tag=1

