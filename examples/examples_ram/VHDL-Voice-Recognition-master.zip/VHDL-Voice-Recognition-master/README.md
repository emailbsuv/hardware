# VHDL-Voice-Recognition
Speech Recognition System implemented in FPGA boards (BASYS2) using VHDL. I used 2 BASYS 2 FPGA boards to implement this project because project's required RAM space and processing capacity exceed BASYS2's recources.

<b>For complete report:</b>
https://drive.google.com/file/d/0B55FMowYZhIfU0t5TDFfQmM4MWM/view?usp=sharing
