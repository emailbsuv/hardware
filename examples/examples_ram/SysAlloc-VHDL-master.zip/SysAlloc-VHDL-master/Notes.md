# RAM-Buddy-VHDL
VHDL development of the RAM-based Buddy Allocator

IMPORTANT NOTE FOR MYSELF

in the previous implementation, input request size 000 means 1 block, 001 means 2 block.
now 000 means 0 block, 001 means 1 block!

change the MMU top level logics for this!
