# ed2-ram00
ram en verilog implementada en luts de una fpga

mensajes del sintetizador

Xst:2546 - "ram.v" line 38: reading initialization file "ram_init.txt".

Xst:3231 - The small RAM <Mram_mem> will be implemented on LUTs 
in order to maximize performance and save block RAM resources. 
If you want to force its implementation on block, use option/constraint ram_style.

