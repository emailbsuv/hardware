VHDL SHA-256 Module
===================

This code contains a simple SHA-256 module and a testbench for verifying that it works.

The implementation is focused on being easy to read and understand and not on having great performance.

