# README should be updated with questions, ideas, problems and solutions.

## Todo:

* Rework IMEM for hardocded values
* Get working test bench for non pipelined
* Case statements for Decoder

**Update 4/21 9pm:**
Still trying to get the unpipelined working. The registers are correctly piping from the instructions but the write back doesnt seem to be working as the register never changes.
