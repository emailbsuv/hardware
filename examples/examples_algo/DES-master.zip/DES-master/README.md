# DES

this project is about designing a DES encryption (Data Encryption Standard) with all its stages 


VHDL
