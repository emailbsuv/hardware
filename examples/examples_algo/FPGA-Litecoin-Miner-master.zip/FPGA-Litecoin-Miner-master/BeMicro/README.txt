BeMicro port by litecoin forum member "Minor" https://forum.litecoin.net/index.php?action=profile;u=15431

+-------------------------------------------------------------------------------+
; Flow Summary                                                                  ;
+------------------------------------+------------------------------------------+
; Flow Status                        ; Successful - Wed Sep 18 13:46:51 2013    ;
; Quartus II Version                 ; 10.1 Build 153 11/29/2010 SJ Web Edition ;
; Revision Name                      ; ltcminer                                 ;
; Top-level Entity Name              ; ltcminer                                 ;
; Family                             ; Cyclone IV E                             ;
; Device                             ; EP4CE22F17C7                             ;
; Timing Models                      ; Final                                    ;
; Total logic elements               ; 18,713 / 22,320 ( 84 % )                 ;
;     Total combinational functions  ; 16,012 / 22,320 ( 72 % )                 ;
;     Dedicated logic registers      ; 10,483 / 22,320 ( 47 % )                 ;
; Total registers                    ; 10483                                    ;
; Total pins                         ; 9 / 154 ( 6 % )                          ;
; Total virtual pins                 ; 0                                        ;
; Total memory bits                  ; 524,288 / 608,256 ( 86 % )               ;
; Embedded Multiplier 9-bit elements ; 0 / 132 ( 0 % )                          ;
; Total PLLs                         ; 1 / 4 ( 25 % )                           ;
+------------------------------------+------------------------------------------+
