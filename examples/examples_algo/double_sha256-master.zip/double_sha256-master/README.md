double_sha256
=============

double sha256 verilog file for bitcoin-like miners.

1:2014/12/14--

  This is a unrolled version, used 132 states.
  
  The first result is outputed at the 132th cycle, then one result per cycle.
  
  The critical path is add_3:e1 + ch + reg.
  
  One engine(dsha_core) has about 50k registers, 
  
  One core area estimate: about 1mm^2 @65nm, run in 333Mhz.

  
