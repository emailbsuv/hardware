Ethernet Mac - VHDL Implementation
==============================

Description
-----------

A VHDL implementation of an Ethernet MAC for use on FPGAs

Further reading
--------------------

http://www.bytebash.com