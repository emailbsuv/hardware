SPI-Servo-Controller
====================

An SPI Servo Controller module for FPGA's written in verilog.

This is synthesizable on most devices.  There is a qpf file that can be used with Quartus for pin mapping on the DE0 Nano.
