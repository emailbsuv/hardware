uart-bidirectional
==================

UART Module(TX+RX)

Use uarttx.v in your design. See top.v for an example on how to use uarttx.v.
top.v does a loopback test.

Targetted for ML506 Virtex-5 with 27MHz clock. Change the parameter div to use different clock frequency and pincon.ucf if targetting a different board.
