SPI-UART-Loopback
=================

SPI(half duplex) and UART loop back demo on ML506 Virtex-5. Clock at 27Mhz and 115200 is the baud rate.

Receives stuff on UART, goes through SPI and is fed back to the UART.
