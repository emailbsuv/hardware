SPI Slave module(clockless)

