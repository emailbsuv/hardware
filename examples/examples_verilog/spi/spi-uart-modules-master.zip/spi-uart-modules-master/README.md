spi-uart-modules
================

An assortment of SPI and UART peripheral modules in Verilog, some of which I used for the Jan 2013 130nm tapeout.
