SPI-half duplex
==================

SPI module, master and slave (half duplex)