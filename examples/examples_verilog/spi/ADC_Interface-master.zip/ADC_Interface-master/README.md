# ADC_Interface
Simple SPI interface for AD7908/AD7918/AD7928 written in verilog HDL
