spi_master
==========

Publishing modifications to an LGPL licensed verilog SPI Master controller
