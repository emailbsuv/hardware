#!/bin/sh

cp ../test/spi_base/rc-bytes*.txt ../projnav/xps/pcores/spiifc_v1_00_a/devl/projnav/

