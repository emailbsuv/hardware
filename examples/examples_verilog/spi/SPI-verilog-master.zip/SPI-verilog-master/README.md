SPI-verilog
===========